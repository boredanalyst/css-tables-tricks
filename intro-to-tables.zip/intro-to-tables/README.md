# Intro to Tables

A Pen created on CodePen.io. Original URL: [https://codepen.io/Louis-Christian-Garcia/pen/poqNVRW](https://codepen.io/Louis-Christian-Garcia/pen/poqNVRW).

